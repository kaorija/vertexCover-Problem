package bruteforce;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class BruteForce {
	public static FileWriter  resWriter;
	/*
	 * recursive solver
	 * @purpose:
	 * This is the recursive function for constructing the combination of K vertices
	 * @paramms:
	 * N - the number of graph vertices
	 * K - the number of vertices to be selected
	 * startV - current starting vertex
	 * edgeList - edge list of the graph
	 * vertexSet - 1 if vertex is selected, 0 - if vertex is not selected yet
	 * @return:
	 * true - if there is a vertex cover of size K
	 * */
	public static boolean solveRecursive(int N, int K, int startV, int vertexSet[], ArrayList<Integer> edgeList[]) throws IOException {
		if ( K == 0 ) {//find all vertex set
			boolean res = true;
			for ( int i = 0; i < N && res; i++) {//for every vertex
				if ( vertexSet[i] == 1) continue;
				int N1 = edgeList[i].size();
				for ( int k = 0; k < N1; k++) {//for every edge connected with the vertex i
					int j = edgeList[i].get(k);
					if ( vertexSet[j] == 0) {
						res = false;
						break;
					}
				}
			}
			if ( res ) {//print the solution if it is found
				System.out.print ( "Vertex Cover: { ");
				resWriter.write("Vertex Cover: { ");
				for ( int i = 0; i < N; i++) {
					if ( vertexSet[i] == 1) {
						System.out.print( " " + i );
						resWriter.write(" " + i);
					}
				}
				System.out.println ( " } ");
				resWriter.write(" } \n");
			}
			return res;
		}
		// select current vertex from startV to N - 1
		for ( int i = startV; i < N; i++) {
			vertexSet[i] = 1;//select
			if (solveRecursive ( N, K - 1, i + 1, vertexSet, edgeList)) {
				return true;
			}
			vertexSet[i] = 0;
		}
		return false;
	}
	
	/*
	 * vertex cover solver
	 * @purpose:
	 * decide whether there is a vertex cover of size K or less
	 * @params:
	 * N - number of vertices of graph
	 * K - maximum number of vertex cover set
	 * edgeList - edge list of the graph 
	 * */
	public static void solveVertexCover ( int N, int K, ArrayList<Integer> edgeList[]) throws IOException {
		int[] vertexSet = new int[N];
		for ( int i = 0; i < N; i++) vertexSet[i] = 0;
		if ( solveRecursive ( N, K, 0, vertexSet, edgeList)) {
			System.out.println ( "There is a vertex cover of size " + K);
			resWriter.write("There is a vertex cover of size " + K + "\n");
		}
		else {
			System.out.println ( "There is no vertex cover of size " + K);
			resWriter.write("There is no vertex cover of size " + K + "\n");
		}
	}
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int N, M;
		/* test every test case */
		//result file name
		String resFileName = "BruteForceResult.txt";
		try {
			resWriter = new FileWriter  ( resFileName);		
			for ( int testCase = 1; testCase <= 5; testCase++) {
				/* read file */
				System.out.println ( "=================================================");
				resWriter.write("=================================================\n");
				//file name
				String fileName = "test" + Integer.toString(testCase) + ".txt";
				try {
					Scanner scanner = new Scanner ( new File (fileName));
					N = scanner.nextInt();
					M = scanner.nextInt();
					
					//edge list
					ArrayList< Integer>[] edgeList = new ArrayList[N];
					for ( int k = 0; k < N; k++) {
						edgeList[k] = new ArrayList<Integer>();
					}

					for ( int k = 0; k < M; k++) {
						int i = scanner.nextInt();
						int j = scanner.nextInt();
						edgeList[i].add(j);
						edgeList[j].add(i);
					}
					scanner.close();
					//starting time
					
					int[] KK = new int[2];
					KK[0] = N/2;
					KK[1] = N/3;
					for ( int k = 0; k < 2; k++) {//k - half and one third of the number of vertices
						int K = KK[k];
						long start_at = System.currentTimeMillis();
						System.out.println ( "Solving " + fileName + " With K="+ K + " By Brute Force Method...");
						System.out.println ( "Number of Vertecies: " + N + "  Number of Edges: " + M);
						
						resWriter.write("Solving " + fileName + " With K="+ K + " By Brute Force Method...\n");
						resWriter.write("Number of Vertecies: " + N + "  Number of Edges: " + M + "\n");
						/* calculate vertex cover problem by brute force*/
						solveVertexCover ( N, K, edgeList);
						long end_at = System.currentTimeMillis();
						long execute_time = end_at - start_at;
						System.out.println ( "Execution Time: " + execute_time + "(ms)\n");
						resWriter.write("Execution Time: " + execute_time + "(ms)\n\n");
					}

					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println ( "Test File Not Found");
					resWriter.write("Test File Not Found\n");
				}
				
			}	
			resWriter.close();
		} catch ( Exception e) {
			System.out.println ( "Could not create the result file name");
		}
		

	}

}

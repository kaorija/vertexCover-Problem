package input;

import java.util.Random;
import java.io.FileWriter;

public class CreateInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random random = new Random();
		int testCase = 0;
		for ( int N = 22; N <=30; N += 2) {
			int numEdges = N*(N - 1)/2;
			int M = numEdges/2;
			int[][] con = new int[N][N];
			for ( int i = 0; i < N; i++) {
				for ( int j = 0; j < N; j++) {
					con[i][j] = 0;
				}
			}
			for ( int k = 0; k < M; k++) {
				int i = random.nextInt(N);
				int j = random.nextInt(N);
				while ( i == j || con[i][j] == 1 || i < (N/2) || j < (N/4)) {
					i = random.nextInt(N);
					j = random.nextInt(N);
				}
				con[i][j] = con[j][i] = 1;
			}
			testCase++;
			String fileName = "test" + Integer.toString(testCase) + ".txt";
			try {
				FileWriter  writer = new FileWriter  ( fileName);
				writer.write(N + "\t" + M + "\n");
				for ( int i = 0; i < N; i++) {
					for ( int j = i + 1; j < N; j++) {
						if ( con[i][j] == 1) {
							writer.write(i + "\t" + j + "\n");
						}
					}
				}
				writer.close();
				System.out.println ( fileName + " was created. ( N = " + N + ", M = " + M + " )");
			}
			catch ( Exception e) {
				System.out.println ( fileName + " failed to be created");
			}
		}
	}

}

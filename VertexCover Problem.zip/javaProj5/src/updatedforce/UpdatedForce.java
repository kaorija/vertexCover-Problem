package updatedforce;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class UpdatedForce {
	public static FileWriter  resWriter;
	/*
	 * recursive solver
	 * @purpose:
	 * This is the recursive function for constructing the combination of K vertices
	 * @paramms:
	 * N - the number of graph vertices
	 * K - the number of vertices to be selected
	 * startV - current starting vertex
	 * edgeList - edge list of the graph
	 * vertexSet - 1 if vertex is selected, 0 - if vertex is not selected yet
	 * vertexOrd - order of the vertex index according to the size of edge list connected to the vertex
	 * @return:
	 * true - if there is a vertex cover of size K
	 * */	
	public static boolean solveRecursive(int N, int K, int startV, int vertexSet[], int vertexOrd[], ArrayList<Integer> edgeList[]) throws IOException {
		if ( K == 0 ) {//find all vertex set
			boolean res = true;
			for ( int i = 0; i < N && res; i++) {//for every vertex
				if ( vertexSet[i] == 1) continue;
				int N1 = edgeList[i].size();
				for ( int k = 0; k < N1; k++) {//for every edge list connected to the current vertex i
					int j = edgeList[i].get(k);
					if ( vertexSet[j] == 0) {
						res = false;
						break;
					}
				}
			}
			if ( res ) {//print the solution if it is found
				System.out.print ( "Vertex Cover: { ");
				resWriter.write("Vertex Cover: { ");
				for ( int i = 0; i < N; i++) {
					if ( vertexSet[i] == 1) {
						System.out.print( " " + i );
						resWriter.write(" " + i);
					}
				}
				System.out.println ( " } ");
				resWriter.write(" } \n");
			}
			return res;
		}
		//select current vertex
		for ( int i = startV; i < N; i++) {
			//select vertex according to the size of edge list connected to the vertex
			//that is, the number of edge list is greater, it should be first
			int ii = vertexOrd[i];
			vertexSet[ii] = 1;
			if (solveRecursive ( N, K - 1, i + 1, vertexSet, vertexOrd, edgeList)) {
				return true;
			}
			vertexSet[ii] = 0;
		}
		return false;
	}
	
	/*
	 * vertex cover solver
	 * @purpose:
	 * decide whether there is a vertex cover of size K or less
	 * @params:
	 * N - number of vertices of graph
	 * K - maximum number of vertex cover set
	 * edgeList - edge list of the graph 
	 * */	
	public static void solveVertexCover ( int N, int K, ArrayList<Integer> edgeList[]) throws IOException {
		int[] vertexSet = new int[N];
		for ( int i = 0; i < N; i++) vertexSet[i] = 0;
		
		/* update method */
		//we store the id of the vertex in the order of large size of edges
		int[] vertexOrd = new int[N];
		for ( int i =0 ; i < N; i++) {
			vertexOrd[i] = i;
		}
		//sort the vertex according to the size of edge list connected to it
		for ( int i = 0; i < N; i++) {
			for ( int j = i + 1; j < N; j++) {
				int ii = vertexOrd[i];
				int jj = vertexOrd[j];
				if ( edgeList[ii].size() < edgeList[jj].size()) {
					vertexOrd[i] = jj;
					vertexOrd[j] = ii;
				}
			}
		}

		if ( solveRecursive ( N, K, 0, vertexSet, vertexOrd, edgeList)) {//found the vertex cover of size K
			System.out.println ( "There is a vertex cover of size " + K);
			resWriter.write("There is a vertex cover of size " + K + "\n");
		}
		else {//failed to find vertex cover of size K
			System.out.println ( "There is no vertex cover of size " + K);
			resWriter.write("There is no vertex cover of size " + K + "\n");
		}
	}
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		String resFileName = "UpdatedMethodResult.txt";
		resWriter = new FileWriter (resFileName);
		// TODO Auto-generated method stub
		int N, M;
		/* test every test case */
		for ( int testCase = 1; testCase <= 5; testCase++) {
			System.out.println ( "=================================================");
			resWriter.write("=================================================\n");
			/* read file */
			//file name
			String fileName = "test" + Integer.toString(testCase) + ".txt";
			try {
				Scanner scanner = new Scanner ( new File (fileName));
				N = scanner.nextInt();
				M = scanner.nextInt();
				
				//edge list
				ArrayList< Integer>[] edgeList = new ArrayList[N];
				for ( int k = 0; k < N; k++) {
					edgeList[k] = new ArrayList<Integer>();
				}

				for ( int k = 0; k < M; k++) {
					int i = scanner.nextInt();
					int j = scanner.nextInt();
					edgeList[i].add(j);
					edgeList[j].add(i);
				}
				scanner.close();

				int[] KK = new int[2];
				KK[0] = N/2;
				KK[1] = N/3;
				for ( int k = 0; k < 2; k++) {
					int K = KK[k];
					long start_at = System.currentTimeMillis();
					System.out.println ( "Solving " + fileName + " With K="+ K + " By Updated Method...");
					System.out.println ( "Number of Vertecies: " + N + "  Number of Edges: " + M);
					
					resWriter.write("Solving " + fileName + " With K="+ K + " By Updated Method...\n");
					resWriter.write("Number of Vertecies: " + N + "  Number of Edges: " + M + "\n");
					/* calculate vertex cover problem by brute force*/
					solveVertexCover ( N, K, edgeList);
					long end_at = System.currentTimeMillis();
					long execute_time = end_at - start_at;
					System.out.println ( "Execution Time: " + execute_time + "(ms)\n");
					resWriter.write("Execution Time: " + execute_time + "(ms)\n\n");
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println ( "Test File Not Found");
				resWriter.write("Test File Not Found\n");
			}
			
		}
		resWriter.close();
	}

}

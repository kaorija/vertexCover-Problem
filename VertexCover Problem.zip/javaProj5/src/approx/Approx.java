package approx;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class Approx {
	public static FileWriter  resWriter;	
	/*
	 * vertex cover solver
	 * @purpose:
	 * find the optimal size K for vertex cover
	 * @params:
	 * N - number of vertices of graph
	 * edgeList - edge list of the graph 
	 * */	
	public static void solveVertexCover ( int N, ArrayList<Integer> edgeList[]) throws IOException {
		/* construct edge set E from edge list */
		//first vertex list of edge
		ArrayList<Integer> firstE = new ArrayList<Integer>();
		// second vertex list of edge
		ArrayList<Integer> secondE = new ArrayList<Integer>();
		for ( int i = 0; i < N; i++) {
			int N1 = edgeList[i].size();
			for ( int k = 0; k < N1; k++) {//for every edge
				int j = edgeList[i].get(k);
				if ( j > i ) {
					firstE.add(i);
					secondE.add(j);
				}
			}
		}
		//vertex cover set
		ArrayList<Integer> vertexSet = new ArrayList<Integer>();
		//while E is not Empty
		while ( firstE.size() > 0 ) {
			//select one edge
			int ii = firstE.get(0);
			int jj = secondE.get(0);
			//add the selected edge to the vertex set
			vertexSet.add(ii);
			vertexSet.add(jj);
			int remainN = firstE.size();
			for ( int k = remainN - 1; k >=0; k--) {//for every remaining edges
				int i = firstE.get(k);
				int j = secondE.get(k);
				//remove the edge connected to either one vertex of the selected edge
				if ( i == ii || i == jj || j == ii || j == jj) {
					firstE.remove(k);
					secondE.remove(k);
				}
			}
		}
		
		System.out.println ( "The number of verticies in vertex cover set: " + vertexSet.size());
		System.out.print( "{ ");
		resWriter.write("The number of verticies in vertex cover set: " + vertexSet.size() + "\n");
		resWriter.write("{ ");
		for ( int i = 0; i < vertexSet.size(); i++) {
			System.out.print( " " + vertexSet.get(i));
			resWriter.write(" " + vertexSet.get(i));
		}
		System.out.println(" } ");
		resWriter.write(" } \n");
	}
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String resFileName = "ApproxResult.txt";
		resWriter = new FileWriter ( resFileName);
		int N, M;
		/* test every test case */
		for ( int testCase = 1; testCase <= 5; testCase++) {
			System.out.println ( "=================================================");
			resWriter.write("=================================================\n");
			/* read file */
			//file name
			String fileName = "test" + Integer.toString(testCase) + ".txt";
			try {
				Scanner scanner = new Scanner ( new File (fileName));
				N = scanner.nextInt();
				M = scanner.nextInt();
				
				//edge list
				ArrayList< Integer>[] edgeList = new ArrayList[N];
				for ( int k = 0; k < N; k++) {
					edgeList[k] = new ArrayList<Integer>();
				}

				for ( int k = 0; k < M; k++) {
					int i = scanner.nextInt();
					int j = scanner.nextInt();
					edgeList[i].add(j);
					edgeList[j].add(i);
				}
				scanner.close();
				//starting time
				long start_at = System.currentTimeMillis();
				System.out.println ( "Solving " + fileName + " By Approx Method...");
				System.out.println ( "Number of Vertecies: " + N + "  Number of Edges: " + M);

				resWriter.write("Solving " + fileName + " By Approx Method...\n");
				resWriter.write("Number of Vertecies: " + N + "  Number of Edges: " + M + "\n");
				/* calculate vertex cover problem by brute force*/

				solveVertexCover ( N, edgeList);
				long end_at = System.currentTimeMillis();
				long execute_time = end_at - start_at;
				System.out.println ( "Execution Time: " + execute_time + "(ms)\n");
				resWriter.write("Execution Time: " + execute_time + "(ms)\n\n");
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println ( "Test File Not Found");
				resWriter.write("Test File Not Found\n");
			}
			
		}
		resWriter.close();
	}

}
